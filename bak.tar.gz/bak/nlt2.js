
/*
 * Defines a shape using a non-linear (arbitrary) transformation, f(x, y)->(x, y)'.
 * Outlines should be lists of points, which are connected by a line segment.
 * 
 * min_px defines a threshold to throw out segments,
 * until the distance between the first and last transformed point exceeds the threshold.
 * 
 */
// recursive division and agglomeration
// DIV: for a line to, test if midpoint is colinear; if not, recursively line to until sufficient colinearity is found
// AGG: if current point is colinear with next point, don't add it

function nltFill3(ctx, outlines, t, cls2, tpt) {
//	var cls2 = cls / 2;
	var outlinen = outlines.length;
	for (var outlinei = 0; outlinei < outlinen; ++outlinei) {
		var outline = outlines[outlinei];
		nltFill3_(ctx, outline, t, cls2, tpt);
	}
}
function nltFill3_(ctx, outline, t, cls2, tpt) {
	var n = outline.length;
	t(outline[0], outline[1], tpt);
	var mx = tpt[0];
	var my = tpt[1];
	var px = tpt[0];
	var py = tpt[1];
	ctx.beginPath();
	ctx.moveTo(px, py);
	t(outline[2], outline[3], tpt);
	var x = tpt[0];
	var y = tpt[1];
//		var lx = px;
//		var ly = py;
	for (var i = 4; i < n; i += 2) {
//			alert("[" + i + "] / " + n);
		t(outline[i], outline[i + 1], tpt);
		var nx = tpt[0];
		var ny = tpt[1];
		/*
			var dx = x - x0;
			var dy = y - y0;
			if (minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) {
				ctx.lineTo(x, y);
//				alert("line to " + x + ", " + y);
				x0 = x;
				y0 = y;
			}
			*/
//			lineto(ctx, 
//					px, py, outline[i - 4], outline[i - 3], 
//					x, y, outline[i - 2], outline[i - 1],
//					nx, ny, 
//					cls, t, tpt);
//			var dx = x - lx;
//			var dy = y - ly;
//			if ((minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) 
//					//&& !isCollinear(px, py, x, y, nx, ny, cls2)
//					) {
			lineto3(ctx, 
					px, py, outline[i - 4], outline[i - 3], 
					x, y, outline[i - 2], outline[i - 1],
					nx, ny,
					cls2, t, tpt);
//				lx = x;
//				ly = y;
//			}
		px = x;
		py = y;
		x = nx;
		y = ny;
	}
	lineto3(ctx, 
			px, py, outline[n - 4], outline[n - 3],
			x, y, outline[n - 2], outline[n - 1],
			mx, my,
			cls2, t, tpt);
	//ctx.lineTo(mx, my);
	// Close
	lineto3(ctx, 
			x, y, outline[n - 2], outline[n - 1],
			mx, my, outline[0], outline[1],
			mx, my,
			cls2, t, tpt);
	ctx.closePath();
	ctx.fill();
}

function nltFill2(ctx, outlines, t, cls2, tpt) {
//	var cls2 = cls / 2;
	var outlinen = outlines.length;
	
	for (var outlinei = 0; outlinei < outlinen; ++outlinei) {
		var outline = outlines[outlinei];
		var n = outline.length;
		t(outline[0], outline[1], tpt);
		var mx = tpt[0];
		var my = tpt[1];
		var px = tpt[0];
		var py = tpt[1];
		ctx.beginPath();
		ctx.moveTo(px, py);
		t(outline[2], outline[3], tpt);
		var x = tpt[0];
		var y = tpt[1];
//		var lx = px;
//		var ly = py;
		for (var i = 4; i < n; i += 2) {
//			alert("[" + i + "] / " + n);
			t(outline[i], outline[i + 1], tpt);
			var nx = tpt[0];
			var ny = tpt[1];
			/*
			var dx = x - x0;
			var dy = y - y0;
			if (minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) {
				ctx.lineTo(x, y);
//				alert("line to " + x + ", " + y);
				x0 = x;
				y0 = y;
			}
			*/
//			lineto(ctx, 
//					px, py, outline[i - 4], outline[i - 3], 
//					x, y, outline[i - 2], outline[i - 1],
//					nx, ny, 
//					cls, t, tpt);
//			var dx = x - lx;
//			var dy = y - ly;
//			if ((minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) 
//					//&& !isCollinear(px, py, x, y, nx, ny, cls2)
//					) {
				lineto2(ctx, 
						px, py, outline[i - 4], outline[i - 3], 
						x, y, outline[i - 2], outline[i - 1],
						nx, ny,
						cls2, t, tpt);
//				lx = x;
//				ly = y;
//			}
			px = x;
			py = y;
			x = nx;
			y = ny;
		}
		lineto2(ctx, 
				px, py, outline[n - 4], outline[n - 3],
				x, y, outline[n - 2], outline[n - 1],
				mx, my,
				cls2, t, tpt);
		//ctx.lineTo(mx, my);
		// Close
		lineto2(ctx, 
				x, y, outline[n - 2], outline[n - 1],
				mx, my, outline[0], outline[1],
				mx, my,
				cls2, t, tpt);
		ctx.closePath();
		ctx.fill();
	}
}

function nltFill1(ctx, outlines, t, cls2, tpt) {
//	var cls2 = cls / 2;
	for (var outlinei = 0, outlinen = outlines.length; outlinei < outlinen; ++outlinei) {
		ctx.beginPath();
		var outline = outlines[outlinei];
		var n = outline.length;
		t(outline[0], outline[1], tpt);
		var mx = tpt[0];
		var my = tpt[1];
		var px = tpt[0];
		var py = tpt[1];
		ctx.moveTo(px, py);
		t(outline[2], outline[3], tpt);
		var x = tpt[0];
		var y = tpt[1];
		for (var i = 4; i < n; i += 2) {
			t(outline[i], outline[i + 1], tpt);
			var nx = tpt[0];
			var ny = tpt[1];
			lineto1(ctx, 
					px, py, outline[i - 4], outline[i - 3], 
					x, y, outline[i - 2], outline[i - 1],
					nx, ny,
					cls2, t, tpt);
			px = x;
			py = y;
			x = nx;
			y = ny;
		}
		lineto1(ctx, 
				px, py, outline[n - 4], outline[n - 3],
				x, y, outline[n - 2], outline[n - 1],
				mx, my,
				cls2, t, tpt);
		// Close
		lineto1(ctx, 
				x, y, outline[n - 2], outline[n - 1],
				mx, my, outline[0], outline[1],
				mx, my,
				cls2, t, tpt);
		ctx.closePath();
		ctx.fill();
	}
}

// places lineTo onto the context up to (x, y), given 1st order history and future
/*
function lineto(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls, t, tpt) {
	if (! isCollinear(px, py, x, y, nx, ny, cls)) {
		lineto2(ctx, px, py, opx, opy, x, y, ox, oy, cls, t, tpt);
	}
	// else wait for the line in the future
}
*/
function lineto3(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls2, t, tpt) {
	var omidx = (opx + ox) / 2;
	var omidy = (opy + oy) / 2;
	var omid1x = (opx + omidx) / 2;
	var omid1y = (opy + omidy) / 2;
	var omid2x = (omidx + ox) / 2;
	var omid2y = (omidy + oy) / 2;
	
	t(omidx, omidy, tpt);
	var midx = tpt[0];
	var midy = tpt[1];
//	if (isCollinear(px, py, midx, midy, x, y, cls2)) {
		// 2nd order
		
		t(omid1x, omid1y, tpt);
		var mid1x = tpt[0];
		var mid1y = tpt[1];
		
		t(omid2x, omid2y, tpt);
		var mid2x = tpt[0];
		var mid2y = tpt[1];
		
		var c1 = isCollinear(px, py, mid1x, mid1y, midx, midy, cls2);
		var c2 = isCollinear(midx, midy, mid2x, mid2y, x, y, cls2);
		if (c1 && c2) {
			if (! isCollinear(px, py, x, y, nx, ny, cls2)) {
				ctx.lineTo(x, y);
			}
		}
		else if (c1) {
			ctx.lineTo(midx, midy);
			
			lineto3(ctx, midx, midy, omidx, omidy, mid2x, mid2y, omid2x, omid2y, mid2x, mid2y, cls2, t, tpt);
			lineto3(ctx, mid2x, mid2y, omid2x, omid2y, x, y, ox, oy, nx, ny, cls2, t, tpt);
		}
		else if (c2) {
			
			lineto3(ctx, px, py, opx, opy, mid1x, mid1y, omid1x, omid1y, mid1x, mid1y, cls2, t, tpt);
			lineto3(ctx, mid1x, mid1y, omid1x, omid1y, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
			ctx.lineTo(x, y);
		}
		
//	}
	else {
		// Subdivide both sides
//		lineto3(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
//		lineto3(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
		lineto3(ctx, px, py, opx, opy, mid1x, mid1y, omid1x, omid1y, mid1x, mid1y, cls2, t, tpt);
		lineto3(ctx, mid1x, mid1y, omid1x, omid1y, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
		lineto3(ctx, midx, midy, omidx, omidy, mid2x, mid2y, omid2x, omid2y, mid2x, mid2y, cls2, t, tpt);
		lineto3(ctx, mid2x, mid2y, omid2x, omid2y, x, y, ox, oy, nx, ny, cls2, t, tpt);
	}
}
function lineto2(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls2, t, tpt) {
	var omidx = (opx + ox) / 2;
	var omidy = (opy + oy) / 2;
	
	t(omidx, omidy, tpt);
	var midx = tpt[0];
	var midy = tpt[1];
//	if (isCollinear(px, py, midx, midy, x, y, cls2)) {
		// 2nd order
		
		if (isCollinear(px, py, midx, midy, x, y, cls2)) {
			if (! isCollinear(px, py, x, y, nx, ny, cls2)) {
				ctx.lineTo(x, y);
			}
		}
		
		
//	}
	else {
		// Subdivide both sides
//		lineto3(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
//		lineto3(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
		lineto2(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
		lineto2(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
	}
}
function lineto1(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls2, t, tpt) {
	if (! isCollinear(px, py, x, y, nx, ny, cls2)) {
	
	var omidx = (opx + ox) / 2;
	var omidy = (opy + oy) / 2;
	
	t(omidx, omidy, tpt);
	var midx = tpt[0];
	var midy = tpt[1];
//	if (isCollinear(px, py, midx, midy, x, y, cls2)) {
		// 2nd order
		
		if (isCollinear(px, py, midx, midy, x, y, cls2)) {
			ctx.lineTo(x, y);
		}
		else {
			
			// Subdivide both sides
	//		lineto3(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
	//		lineto3(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
			lineto1(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
			lineto1(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
		}
	}
}
function isCollinear(x1, y1, x2, y2, x3, y3, cls2) {
	return Math.abs(x3 * (y1 - y2) + x1 * (y2 - y3) + x2 * (y3 - y1)) <= cls2;
}


// use the elliptic LUT
// ept = [x, depth]
// len must be positive
function ellipticPt(tw, len, ept) {
	var s = elliptic_lut_tw / tw;
	len *= s;
	var i = 2 * (elliptic_ss_lut_max - 1 < len
        	? elliptic_ss_lut_max - 1
        	: Math.floor(len));
	ept[0] = elliptic_ss_lut[i] / s;
	ept[1] = elliptic_ss_lut[i + 1];
}
/*
function ellipticPtNorm(len, ept) {
	var e = elliptic_ss_lut[elliptic_ss_lut_max - 1 < len
        	? elliptic_ss_lut_max - 1
        	: Math.floor(len)];
	ept[0] = e[3];
	ept[1] = e[4];
//	if (e[0] < 0) {
//		ept[0] = elliptic_lut[e[1]][1];
//		ept[1] = elliptic_lut[e[1]][2];
//	}
//	else if (elliptic_lut.length <= e[1]) {
//		ept[0] = elliptic_lut[e[0]][1];
//		ept[1] = elliptic_lut[e[0]][2];
//	}
//	else {
//	var i0 = e[0];
//	var i1 = e[1];
//		var u = e[2];
//		ept[0] = elliptic_lut[i0][1] * (1 - u) + elliptic_lut[i1][1] * u;
//		ept[1] = elliptic_lut[i0][2] * (1 - u) + elliptic_lut[i1][2] * u;
//	}
}
*/
function stepf(u) {
	if (1 <= u) { return 0; }
	var i = step_lut_sample_n * u;
	var i0 = Math.floor(i);
	var iu = i - i0;
	return iu <= 0 ? step_lut[i0] : ((1 - iu) * step_lut[i0] + iu * step_lut[i0 + 1]);
}

/*
 * Samples the unit space based on p
 * Breaks into fs.length equally spaces units
 * centers a Stepf on each unit
 * hfLut[i] represents the height fraction for sample i
 */
function createHfLut(fs, hfLut, n) {
	//var n = 1 + Math.ceil(1.0 / p);
	var b = 0.65;
	var u0 = 0.0;
	var u1 = 1.0;
	var nn = 1;
	var fsn = fs.length;
	var fis = (u1 - u0) / fsn;
	for (var i = 0; i < n; ++i) {
		var u = (1.0 * i) / n;
		var fic = Math.floor(fsn * u);
		var v = 0;
		var fi0 = Math.max(0, fic - nn), fi1 = Math.min(fsn - 1, fic + nn);
		for (var fi = fi0;
			fi <= fi1; ++fi) {
			var ficu = u0 + fis / 2 + fis * fi;
			var su = b * (u - ficu) * 2.0 / fis;
//			alert("" + fi + ":" + su);
			v += fs[fi] * (su < 0 ? stepf(-su) : stepf(su));
		}
		hfLut[i] = v;
		
		
		
	}
	hfLut[n] = hfLut[n - 1];
//	alert(hfLut);
}
// u on [0, 1]
function hfLut(hfLut, n, u) {
//	return hfLut[Math.floor(n * u)];
	var i = n * u;
	var i0 = Math.floor(i);
	var iu = i - i0;
	return iu <= 0 ? hfLut[i0] : ((1 - iu) * hfLut[i0] + iu * hfLut[i0 + 1]);
}





function init() {

	resize();
}

function resize() {

	var tw = $("#thesurfaceContainer").width();
	var th = $("#thesurfaceContainer").height();
	
	var thesurface = document.getElementById("thesurface");
	thesurface.width = tw;
	thesurface.height = th;
	

//	$("#thesurface").width($("#thesurfaceContainer").width());
//	$("#thesurface").height($("#thesurfaceContainer").height());
	
	paint();
}


var stepTime0 = 0;
var stepCount = 0;
var stepCountPeriod = 24;
var meanFps = 0;

function step() {
	if (0 == (stepCount % stepCountPeriod)) {
		var time = new Date().getTime();
		meanFps = 1000.0 * stepCountPeriod / (time - stepTime0);
		stepTime0 = time;
//		stepCount = 0;
	}
	++stepCount;
	paint();
}

//var temprfs = new Array(ptn);

var SURFACE_OUTLINE=[[false, 0,0, 0,1, 1,1, 1,0]];

var wlenOff = 0;
var iwlenOff = 0;


var tept = [0, 0];
var tpt = [0, 0];


var thfLutn = 256;
var thfLut0 = new Array(thfLutn + 1);
var thfLut1 = new Array(thfLutn + 1);

var fsn = 20;
var fs0 = [1.0, 0.5, 0.25, 0.125,0.2,0.3,0.4,0.5,0.6,0.7,1.0, 0.5, 0.25, 0.125,0.2,0.3,0.4,0.5,0.6,0.7];
var fs1 = [1.0, 0.5, 0.25, 0.125,0.2,0.3,0.4,0.5,0.6,0.7,1.0, 0.5, 0.25, 0.125,0.2,0.3,0.4,0.5,0.6,0.7];


var py0 = 0.03;
var py1 = 1 - py0;
function py(u) {
	return (1 - u) * py0 + u * py1;
}
var px0 = 0.01;
var px1 = 1 - px0;
function px(u) {
	return (1 - u) * px0 + u * px1;
}

var fsRects = new Array(fsn);
for (var i = 0; i < fsn; ++i) {
	var x0 = px(i / fsn);
	var x1 = px((i + 1) / fsn);
	var y0 = py(0);
	var y1 = py(1);
	fsRects[i] = [x0,y0, x0,y1, x1,y1, x1,y0];
}
var fsStyles = new Array(3 * fsn);
for (var i = 0; i < fsn; ++i) {
	var si0 = 3 * i;
	fsStyles[si0] = 255;
	fsStyles[si0 + 1] = 0;
	fsStyles[si0 + 2] = 0;
}


function paint() {
	
	var thesurface = document.getElementById("thesurface");
	var ctx = thesurface.getContext("2d");
	var w = thesurface.width;
	var h = thesurface.height;
	ctx.save();
		ctx.clearRect(0, 0, w, h);
		var cy = h / 2;
		var th = 100;
		var th1 = 200;
		

		var thfLut = thfLut0;
		var fs = fs0;
		
		
		var netWlenOff = wlenOff + iwlenOff;
		for (var wi = 0; wi < 5; ++wi) {
			
			var outline = outlines[wi];
			
			var ww = outline[1] - outline[0];
			var wh = outline[3] - outline[2];
			
			var wlen = Math.max(500, th * ww / wh);
			
			var t = function(x,y,pt) {
				var l = netWlenOff + x * wlen;
				var s = l < 0 ? -1 : 1;
				ellipticPt(w/2, l * s, tept);
				pt[0] = w/2 + s * tept[0];
				pt[1] = cy + (y - 0.5) * th * ((1-tept[1]) + 0.05 * tept[1]);
			};
			
			ctx.fillStyle = "rgba(0, 0, 0, 255)";
			nltFill1(ctx, outline[4], t, 0.05 / 2, tpt);
			ctx.fillStyle = "rgba(255, 255, 255, 255)";
			nltFill1(ctx, outline[5], t, 0.05 / 2, tpt);
			
			
			
			
			
			netWlenOff += wlen + 100;			
		}
		
		
		
		
		createHfLut(fs, thfLut, thfLutn);
		var wi = wordIndex;
		var outline = outlines[wi];
		var envelope = envelopes[wi];
		
		var ww = outline[1] - outline[0];
		var wh = outline[3] - outline[2];
		var b = 0.45;
		var wlen = Math.max(500, th * ww / wh);
		
		var maxAlphaUnder = 1.0;
		var maxAlphaOver = 0.6;
		
		// style cut off points on either side (transition back to normal)
		var cx0 = 0.4;
		var cx1 = 0.6;
		
		var blend = function(x) {
			return x < cx0 ? (1 - stepf(x / cx0))
					: cx1 <= x ? (1 - stepf((1 - x) / (1 - cx1)))
					: 1;
		}
		var t = function(x,y,pt) {
			pt[0] = w/2 + x * wlen;
			var y0 = (1 - y) * th;
			var y1 =  ((1 - y) * b * th1 + (1 - y) * (1- b) * th1 * hfLut(thfLut, thfLutn, x));
			var bu = blend(x);
			pt[1] = cy - ((1 - bu) * y0 + bu * y1);
		};
		
		
//		ctx.fillStyle = "rgba(230,230,230, 255)";
//		ctx.fillRect(w/2, cy-th, wlen, th)
		
		for (var i = 0; i < fsn; ++i) {
//			if (0 < fs[i]) {
				var si0 = 3 * i;
//				ctx.fillStyle = "rgba(255, 0, 0, 1)";
				var u = fs[i] * blend((i + 0.5) / fsn);
//				var v = 255 * (1 - fs[i]);
				var v = 0;
				ctx.fillStyle = "rgba(" + Math.round(v + u * fsStyles[si0]) + "," + Math.round(v + u * fsStyles[si0 + 1]) + "," + 
				Math.round(v + u * fsStyles[si0 + 2]) + ",1)";
//				ctx.fillStyle = "rgba(0,0,0,1)";
//				ctx.globalAlpha = fs[i] * maxAlphaUnder;
	//			ctx.fillStyle = fsStyles[i];
				nltFill3_(ctx, fsRects[i], t, 0.05 / 2, tpt);
//			}
		}
//		ctx.fillStyle = "rgba(255, 0, 0, 255)";
//		nltFill3(ctx, [[0,0, 0,1, 0.25,1, 0.25,0]], t, 0.05 / 2, tpt);
//		ctx.fillStyle = "rgba(0, 255, 0, 255)";
//		nltFill3(ctx, [[0.25,0, 0.25,1, 0.5,1, 0.5,0]], t, 0.05 / 2, tpt);
//		ctx.fillStyle = "rgba(220,220,220, 1)";
//		ctx.fillRect(w/2, cy-b*th, wlen, b*th);
		
		
//		ctx.fillStyle = "rgba(0, 0, 0, 255)";
//		nltFill3(ctx, outline[4], t, 0.05 / 2, tpt);
//		ctx.fillStyle = "rgba(255, 255, 255, 255)";
//		nltFill3(ctx, outline[5], t, 0.05 / 2, tpt);
//		ctx.fillStyle = "rgba(192, 192, 192, 1)";
		ctx.fillStyle = "rgba(255, 255, 255, 1)";
		nltFill3(ctx, envelope[4], t, 0.05 / 2, tpt);
		
		
//		ctx.fillStyle = "rgba(255, 0, 0, 0.3)";
////		ctx.fillRect(w/2+0.25*wlen, cy-b*th-fs[1]*(1-b)*th, 0.25*wlen, fs[1]*(1-b)*th);
//		nltFill3(ctx, [[0,0, 0,1, 0.25,1, 0.25,0]], t, 0.05 / 2, tpt);
//		ctx.fillStyle = "rgba(0, 255, 0, 0.3)";
////		ctx.fillRect(w/2+0.25*wlen, cy-b*th-fs[1]*(1-b)*th, 0.25*wlen, fs[1]*(1-b)*th);
//		nltFill3(ctx, [[0.25,0, 0.25,1, 0.5,1, 0.5,0]], t, 0.05 / 2, tpt);
		
		var lmarg = 30;
		
		var midsp = wlen / fsn;
		ctx.fontAlign = "left";
		ctx.textBaseline = "bottom";
		ctx.font = Math.min(18, Math.max(10, Math.floor(midsp - 9))) + "px sans-serif"
		for (var i = 0; i < fsn; ++i) {
			var midx = (i + 0.5) / fsn;
			var u = fs[i] * blend(midx);
			if (0 < u) {
				var si0 = 3 * i;
//				ctx.fillStyle = "rgba(255, 0, 0, 1)";
				ctx.fillStyle = "rgba(" + fsStyles[si0] + "," + fsStyles[si0 + 1] + "," + fsStyles[si0 + 2] + "," + (u * maxAlphaOver) + ")";
//				ctx.globalAlpha = fs[i] * maxAlphaOver;
	//			ctx.fillStyle = fsStyles[i];
				nltFill3_(ctx, fsRects[i], t, 0.05 / 2, tpt);
				
				// Axis
				t(midx, 0, tpt);
				dottedLine(ctx, tpt[0], tpt[1] - 4, tpt[0], cy-th1-lmarg, 4, 1);
				var tx = tpt[0];
				var ty = cy-th1-lmarg;
				ctx.translate(tx, ty);
					ctx.rotate(-Math.PI / 4);
					var text = "40% blah";
					dottedLine(ctx, 0, 0, ctx.measureText(text).width + 12, 0, 4, 1);
					ctx.fillText(text, 6, 2);
					ctx.rotate(Math.PI / 4);
				ctx.translate(-tx, -ty);
			}
		}
//		ctx.globalAlpha = 1.0;
		
		// TODO: fill behind text per block
		// TODO: alpha block over text
		
		ctx.fillStyle = "rgba(0, 0, 0, 255)";
		ctx.fillText("" + meanFps, 20, 20);
	ctx.restore();
}


function dottedLine(ctx,x0,y0,x1,y1,sp,r) {
	var dx = x1 - x0;
	var dy = y1 - y0;
	var m = Math.sqrt(dx * dx + dy * dy);
	var n = Math.ceil(m / sp);
	// Adjustment to ensure start and end caps
	var f = m / (sp * n);
	dx *= f * sp / m;
	dy *= f * sp / m;
	var d = 2 * r;
	for (var i = 0; i <= n; ++i) {
		var x = x0 + i * dx;
		var y = y0 + i * dy;
		ctx.fillRect(x-r,y-r,d,d);
	}
}


/*
function textInto(ctx,x0,y0,x1,y1) {
	var p = 1;
	var t = function(x,y,pt) {

		// very cool effect ...
//		pt[0] = w/4 + w/2 * Math.pow(x, p) + w/6 * Math.cos(Math.PI * 2 * x + stepCount * (Math.PI * 2) / 250);
		pt[0] = x0 + (x1 - x0) * Math.pow(x, p);
		pt[1] = y0 + (y1 - y0) * Math.pow(y, p);
	};
	
	ctx.fillStyle = "rgba(0, 0, 0, 255)";
	nltFill2(ctx, outlines[wordIndex][4], t, 0.05, 1);
	ctx.fillStyle = "rgba(255, 255, 255, 255)";
	nltFill2(ctx, outlines[wordIndex][5], t, 0.05, 1);
	
}
*/

//function pinch(fpts, minx, maxx, miny, maxy) {
//	var n = fpts.length;
//	for (var i = 0; i < n; i += 2) {
//		
//	}
//}


var wordIndex = 0;
function click() {
//	wordIndex = (wordIndex + 1) % outlines.length;
	wordIndex = (wordIndex + 1) % outlines.length;
}


var down = false;
var downPt = [0, 0];


function mdown(e) {
	down = true;
	downPt[0] = e.pageX;
	downPt[1] = e.pageY;
	iwlenOff = 0;
}
function mup(e) {
	down = false;
	wlenOff += iwlenOff;
	iwlenOff = 0;
}
function mmove(e) {
	if (down) {
		iwlenOff = e.pageX - downPt[0];
	}
}


$(window).bind("load", init);
$(window).bind("resize", resize);
$(window).bind("click", click);
$(window).bind("mousedown", mdown);
$(window).bind("mouseup", mup);
$(window).bind("mousemove", mmove);

var fps = 200;
var riv = setInterval(step, 1000.0 / fps);

