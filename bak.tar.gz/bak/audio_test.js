

//var a1 = new Audio("03_-_Free_Spirit_(Original_Mix).mp3");
//	a1.autoplay = false;
//	a1.loop = false;
//	a1.controls = false;
//	a1.preload = "auto";
//	a1.load();

function go() {
/*
	var wordAudios = loadAudio(2, 5);
//	document.getElementById("cont").appendChild(a1);
//a1.defaultPlaybackRate = 3;
//a1.playbackRate = 3;

//a1.volume = 0.7;
//a1.play();
//a1.playbackRate = 4;
//a1.currentTime = 0;
//a1.defaultPlaybackRate = 0.2;
	
	wordAudios[0][0].volume = 0.7;
//	wordAudios[0][0].currentTime = 0;
	wordAudios[0][0].play();
	*/
	
	var a = new Audio();
	// "maybe" is the best possible response
	alert(a.canPlayType("audio/mpeg"));
	alert(a.canPlayType("audio/ogg"));
}


function loadAudio(wordn,tempon) {
	var audios = new Array(wordn);
	for (var wi = 0; wi < wordn; ++wi) {
		var tempos = new Array(tempon);
		for (var ti = 0; ti < tempon; ++ti) {
			var a = document.createElement("audio");
			a.setAttribute("src", "audio/word_" + wi + "_" + ti + ".wav");
			a.load();
			tempos[ti] = a;
		}
		audios[wi] = tempos;
	}
	return audios;
}


/*
#
var audioElement = document.createElement('audio');
#
audioElement.setAttribute('src', 'Mogwai2009-04-29_acidjack_t16.ogg');
#
audioElement.load()

audioElement.pause();
audioElement.volume=0;
   1.
      audioElement.currentTime=35;
   2.
      audioElement.play();


*/