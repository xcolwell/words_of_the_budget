
/*
 * Defines a shape using a non-linear (arbitrary) transformation, f(x, y)->(x, y)'.
 * Outlines should be lists of points, which are connected by a line segment.
 * 
 * min_px defines a threshold to throw out segments,
 * until the distance between the first and last transformed point exceeds the threshold.
 * 
 */
// recursive division and agglomeration
// DIV: for a line to, test if midpoint is colinear; if not, recursively line to until sufficient colinearity is found
// AGG: if current point is colinear with next point, don't add it
function nltFill(ctx, outlines, t, cls, minPx) {
	var cls2 = cls / 2;
	var minPx2 = minPx * minPx;
	var outlinen = outlines.length;
	var tpt = [0, 0];
	for (var outlinei = 0; outlinei < outlinen; ++outlinei) {
		var outline = outlines[outlinei];
		var n = outline.length;
		t(outline[1], outline[2], tpt);
		var mx = tpt[0];
		var my = tpt[1];
		var px = tpt[0];
		var py = tpt[1];
		ctx.beginPath();
		ctx.moveTo(px, py);
		t(outline[3], outline[4], tpt);
		var x = tpt[0];
		var y = tpt[1];
//		var lx = px;
//		var ly = py;
		for (var i = 5; i < n; i += 2) {
//			alert("[" + i + "] / " + n);
			t(outline[i], outline[i + 1], tpt);
			var nx = tpt[0];
			var ny = tpt[1];
			/*
			var dx = x - x0;
			var dy = y - y0;
			if (minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) {
				ctx.lineTo(x, y);
//				alert("line to " + x + ", " + y);
				x0 = x;
				y0 = y;
			}
			*/
//			lineto(ctx, 
//					px, py, outline[i - 4], outline[i - 3], 
//					x, y, outline[i - 2], outline[i - 1],
//					nx, ny, 
//					cls, t, tpt);
//			var dx = x - lx;
//			var dy = y - ly;
//			if ((minPx <= dx || minPx <= dy || minPx2 <= dx * dx + dy * dy) 
//					//&& !isCollinear(px, py, x, y, nx, ny, cls2)
//					) {
				lineto3(ctx, 
						px, py, outline[i - 4], outline[i - 3], 
						x, y, outline[i - 2], outline[i - 1],
						nx, ny,
						cls2, t, tpt);
//				lx = x;
//				ly = y;
//			}
			px = x;
			py = y;
			x = nx;
			y = ny;
		}
		lineto3(ctx, 
				px, py, outline[n - 4], outline[n - 3],
				x, y, outline[n - 2], outline[n - 1],
				mx, my,
				cls2, t, tpt);
		//ctx.lineTo(mx, my);
		// Close
		lineto3(ctx, 
				x, y, outline[n - 2], outline[n - 1],
				mx, my, outline[1], outline[2],
				mx, my,
				cls2, t, tpt);
		ctx.closePath();
		ctx.fill();
	}
}
// places lineTo onto the context up to (x, y), given 1st order history and future
/*
function lineto(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls, t, tpt) {
	if (! isCollinear(px, py, x, y, nx, ny, cls)) {
		lineto2(ctx, px, py, opx, opy, x, y, ox, oy, cls, t, tpt);
	}
	// else wait for the line in the future
}
*/
function lineto3(ctx, px, py, opx, opy, x, y, ox, oy, nx, ny, cls2, t, tpt) {
	var omidx = (opx + ox) / 2;
	var omidy = (opy + oy) / 2;
	t(omidx, omidy, tpt);
	var midx = tpt[0];
	var midy = tpt[1];
//	if (isCollinear(px, py, midx, midy, x, y, cls2)) {
		// 2nd order
		t((opx + omidx) / 2, (opy + omidy) / 2, tpt);
		var mid1x = tpt[0];
		var mid1y = tpt[1];
		var c1 = isCollinear(px, py, mid1x, mid1y, midx, midy, cls2);
		t((omidx + ox) / 2, (omidy + oy) / 2, tpt);
		var mid2x = tpt[0];
		var mid2y = tpt[1];
		var c2 = isCollinear(midx, midy, mid2x, mid2y, x, y, cls2);
		if (c1 && c2) {
			if (! isCollinear(px, py, x, y, nx, ny, cls2)) {
				ctx.lineTo(x, y);
			}
		}
		else if (c1) {
			ctx.lineTo(midx, midy);
			var omid2x = (omidx + ox) / 2;
			var omid2y = (omidy + oy) / 2;
			lineto3(ctx, midx, midy, omidx, omidy, mid2x, mid2y, omid2x, omid2y, mid2x, mid2y, cls2, t, tpt);
			lineto3(ctx, mid2x, mid2y, omid2x, omid2y, x, y, ox, oy, nx, ny, cls2, t, tpt);
		}
		else if (c2) {
			var omid1x = (opx + omidx) / 2;
			var omid1y = (opy + omidy) / 2;
			lineto3(ctx, px, py, opx, opy, mid1x, mid1y, omid1x, omid1y, mid1x, mid1y, cls2, t, tpt);
			lineto3(ctx, mid1x, mid1y, omid1x, omid1y, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
			ctx.lineTo(x, y);
		}
		
//	}
	else {
		// Subdivide both sides
//		lineto3(ctx, px, py, opx, opy, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
//		lineto3(ctx, midx, midy, omidx, omidy, x, y, ox, oy, nx, ny, cls2, t, tpt);
		var omid1x = (opx + omidx) / 2;
		var omid1y = (opy + omidy) / 2;
		lineto3(ctx, px, py, opx, opy, mid1x, mid1y, omid1x, omid1y, mid1x, mid1y, cls2, t, tpt);
		lineto3(ctx, mid1x, mid1y, omid1x, omid1y, midx, midy, omidx, omidy, x, y, cls2, t, tpt);
		var omid2x = (omidx + ox) / 2;
		var omid2y = (omidy + oy) / 2;
		lineto3(ctx, midx, midy, omidx, omidy, mid2x, mid2y, omid2x, omid2y, mid2x, mid2y, cls2, t, tpt);
		lineto3(ctx, mid2x, mid2y, omid2x, omid2y, x, y, ox, oy, nx, ny, cls2, t, tpt);
	}
}
function lineto2(ctx, px, py, opx, opy, x, y, ox, oy, cls2, t, tpt) {
	var omidx = (opx + ox) / 2;
	var omidy = (opy + oy) / 2;
	t(omidx, omidy, tpt);
	var midx = tpt[0];
	var midy = tpt[1];
	if (isCollinear(px, py, midx, midy, x, y, cls2)) {
		ctx.lineTo(x, y);
	}
	else {
		// Subdivide both sides
		lineto2(ctx, px, py, opx, opy, midx, midy, omidx, omidy, cls2, t, tpt);
		lineto2(ctx, midx, midy, omidx, omidy, x, y, ox, oy, cls2, t, tpt);
	}
}
function isCollinear(x1, y1, x2, y2, x3, y3, cls2) {
	return Math.abs(x3 * (y1 - y2) + x1 * (y2 - y3) + x2 * (y3 - y1)) <= cls2;
}


function init() {

	resize();
}

function resize() {

	var tw = $("#thesurfaceContainer").width();
	var th = $("#thesurfaceContainer").height();
	
	var thesurface = document.getElementById("thesurface");
	thesurface.width = tw;
	thesurface.height = th;
	

//	$("#thesurface").width($("#thesurfaceContainer").width());
//	$("#thesurface").height($("#thesurfaceContainer").height());
	
	paint();
}


var stepTime0 = 0;
var stepCount = 0;
var stepCountPeriod = 24;
var meanFps = 0;

function step() {
	if (0 == (stepCount % stepCountPeriod)) {
		var time = new Date().getTime();
		meanFps = 1000.0 * stepCountPeriod / (time - stepTime0);
		stepTime0 = time;
//		stepCount = 0;
	}
	++stepCount;
	paint();
}

//var temprfs = new Array(ptn);

var SURFACE_OUTLINE=[[false, 0,0, 0,1, 1,1, 1,0]];

function paint() {
	
	var thesurface = document.getElementById("thesurface");
	var ctx = thesurface.getContext("2d");
	var w = thesurface.width;
	var h = thesurface.height;
	ctx.save();
		ctx.clearRect(0, 0, w, h);
		
		var cy = h / 2;
		textInto(ctx, 10, cy - 5, 20, cy + 5);
		textInto(ctx, 25, cy - 15, 55, cy + 15);
		textInto(ctx, 60, cy - 50, 160, cy + 50);
		textInto(ctx, 165, cy - 100, 365, cy + 100);
		textInto(ctx, 370, cy - 200, 770, cy + 200);
		textInto(ctx, 775, cy - 400, 1575, cy + 400);
		
		
		/*
		 * var p = Math.pow(2.0, Math.sin(stepCount * (Math.PI * 2) / 200));
		var t = function(x,y,pt) {
	
			// very cool effect ...
//			pt[0] = w/4 + w/2 * Math.pow(x, p) + w/6 * Math.cos(Math.PI * 2 * x + stepCount * (Math.PI * 2) / 250);
			pt[0] = w/4 + w/2 * Math.pow(x, p) 
				+ 2 * Math.cos(Math.PI * 2 * y + stepCount * (Math.PI * 2) / 250);
			pt[1] = h/4 + h/2 * Math.pow(y, p)
				+ 2 * Math.cos(Math.PI * 2 * x + stepCount * (Math.PI * 2) / 120);
		};
		
//		ctx.fillStyle = "rgba(0, 0, 0, 255)";
//		alert(outlines[0][4]);
		
//		ctx.fillStyle = "rgba(90, 90, 240, 255)";
//		nltFill(ctx, SURFACE_OUTLINE, t, 0.05, 1);
		
//		ctx.fillStyle = "rgba(0, 0, 0, 255)";
//		ctx.fillStyle = "rgba(255, 255, 255, 255)";
//		nltFill(ctx, envelopes[wordIndex][4], t, 0.05, 1);
		ctx.fillStyle = "rgba(0, 0, 0, 255)";
		nltFill(ctx, outlines[wordIndex][4], t, 0.05, 1);
		ctx.fillStyle = "rgba(255, 255, 255, 255)";
		nltFill(ctx, outlines[wordIndex][5], t, 0.05, 1);
		
		 */
		
		
		ctx.fillStyle = "rgba(0, 0, 0, 255)";
		ctx.fillText("" + meanFps, 20, 20);
	ctx.restore();
}

function textInto(ctx,x0,y0,x1,y1) {
	var p = 1;
	var t = function(x,y,pt) {

		// very cool effect ...
//		pt[0] = w/4 + w/2 * Math.pow(x, p) + w/6 * Math.cos(Math.PI * 2 * x + stepCount * (Math.PI * 2) / 250);
		pt[0] = x0 + (x1 - x0) * Math.pow(x, p);
		pt[1] = y0 + (y1 - y0) * Math.pow(y, p);
	};
	
	ctx.fillStyle = "rgba(0, 0, 0, 255)";
	nltFill(ctx, outlines[wordIndex][4], t, 0.05, 1);
	ctx.fillStyle = "rgba(255, 255, 255, 255)";
	nltFill(ctx, outlines[wordIndex][5], t, 0.05, 1);
	
}

var wordIndex = 0;
function click() {
	wordIndex = (wordIndex + 1) % outlines.length;
}



$(window).bind("load", init);
$(window).bind("resize", resize);
$(window).bind("click", click);

var fps = 200;
var riv = setInterval(step, 1000.0 / fps);

