
/**
 * An n-dimensional Perlin noise generator.
 *
 *<p>References:
 *<a href="http://www.cs.cmu.edu/~mzucker/code/perlin-noise-math-faq.html">
 *http://www.cs.cmu.edu/~mzucker/code/perlin-noise-math-faq.html</a></p>
 */


// FIXME: JS-ify

function NoiseEvalState(n, pown) {
	// [2 n]
	this.corners = new Array(2 * n);
	this.us = new Array(n);
	this.influences = new Array(pown);
	this.grids = new Array(n);
	this.dv = new Array(n);
}

//var nes = new NoiseEvalState(1, 1);


function PerlinNoiseGenerator(n, lgm) {
	this.n = n;
	this.pown = 0x01 << n;
	
	this.m = 0x01 << lgm;	
	this.mmodmask = ( 0x01 << lgm ) - 1;
	
	this.p = populateShifts( new int[ m ] );
	
	this.g = 1 == n 
		? populateGradients1( new float[ m ][ 1 ] )
		: populateGradients( new float[ m ][ n ], n );
};
PerlinNoiseGenerator.prototype.createNoiseEvalState = function() {
	// FIXME
};


public float noise(final NoiseEvalState nes, final SmoothingFunction sf, final float ... coords) {
	assert coords.length == n : "Illegal coordinates; expected (" + n + ")";
	
	if ( coords.length != n ) {
		return 0.f;
	}
	
	// There are <code>pown</code> gradients to the center
	// This scan algorithm repeatedly averages together the front and back,
	//   with step size <code>2</code>, <code>4</code>, <code>8</code>, etc.
	// The first step size cooresponds to the dimension of <code>coords[ n - 1 ]</code> --
	//   this is clearer if you consider each bit position of <code>i</code> below as representing 
	//   either "front" (1) or "back" (0) of a particular dimension
	
	/// [orginial notes] {{{
	// 		scan algorithm:
	// 		start with smallest step size. average (using interpolation 0), store in front index
	// 		repeat with next largest step size (*2); average fronts (using interpolation 1), store in front;
	// 		repeat ...
	// }}}
	
	final int[][] corners = nes.corners;
	final float[] us = nes.us;			
	final float[] influences = nes.influences;
	final int[] grids = nes.grids;
	final float[] dv = nes.dv;
	
	
	for ( int i = 0; coords.length > i; i++ ) {
		final float c = coords[ i ];
		final int 
			g0 = (int) c,
			g1 = 1 + g0;
		
		corners[ 2 * i ] = g0;
		corners[ 2 * i ] = g1;
		us[ i ] = sf.eval( c - g0 );
	}
	
	// Initialize influences:
	for ( int i = 0; pown > i; i++ ) {
		// The bits of <code>i</code> indicate the corner --
		for ( int j = 0; n > j; j++ ) {
			final int g = corners[ 2 * j + (( i >> j ) & 0x01) ];
			grids[ j ] = g;
			dv[ j ] = coords[ j ] - g;
		}
		
		final float[] g = grad( grids );
		
		// Inner product:
		float ip = 0;
		for ( int j = 0; n > j; j++ )
			ip += dv[ j ] * g[ j ];
		
		// Note: do NOT normalize the <code>ip</code> vector!
		
//		assert -1.01f <= ip && ip <= 1.01f;
		
		// DEBUGGING: {
//		logger.debug( "  [noise] ip: " + ip );
		// }
		
		influences[ i ] = ip;
	}
	
	// Scan average:
	int step = 2;
	for ( int d = 0; n > d; d++, step <<= 1 ) {
		int halfStep = step >> 1;
		for ( int i = 0; pown > i; i += step ) {
			influences[ i ] = lerp( influences[ i ], influences[ i + halfStep ],
					us[ d ] );
		}
	}
	
	final float noise = influences[ 0 ];
	
	assert -1.01f <= noise && noise <= 1.01f 
		: "Noise is out of bounds. The calculations must be wrong.";
	
	// max( -1.f, min( 1.f, noise ) )
	return noise < -1.f ? -1.f : noise > 1.f ? 1.f : noise;
}




private static int[] populateShifts(final int[] p) {
	for ( int i = 0; p.length > i; i++ ) {
		p[ i ] = (int) ( Math.random() * p.length );
	}
	return p;
}

private static float[][] populateGradients1(final Random r, final float[][] g) {
	for ( int i = 0; g.length > i; i++ ) {
		g[ i ][ 0 ] = rfloat( r );
	}
	return g;
}

/**
 * Generates random <code>n</code>-dimensional unit vectors
 * to fill <code>g</code>.
 * This algorithm uses <code>n - 1</code> dimensions of support for each vector
 * (by constructing circles (n = 2), spheres (n = 3), and hyper-spheres (n &gt;= 4)).
 * 
 * @param n   Must be &gt;= 2
 */
private static float[][] populateGradients(final Random r, final float[][] g, final int n) {
	if ( n <= 1 ) {
		throw new IllegalArgumentException( "Can only handle unit gradients." );
	}
	
	final int d = n - 1;
	final double[] 
		ts = 	new double[ d ], 
		coss = 	new double[ d ], 
		sins = 	new double[ d ];
	for ( int i = 0; g.length > i; i++ ) {
		for ( int j = 0; ts.length > j; j++ ) {
			final double t = _2_PI * rfloat( r );
			ts[ j ] = t;
			coss[ j ] = Math.cos( t );
			sins[ j ] = Math.sin( t );
		}
		
		// Dimension k is
		// sin(k - 1) * prod( m = n - 2 to k / 2 + 1, cos( m) )
		
		final float[] gi = g[ i ];
		for ( int k = 0; n > k; k++ ) {
			double gk = k >= 1 ? sins[ k - 1 ] : 1.0;
			for ( int m = k; d > m; m++ )
				gk *= coss[ m ];
			gi[ k ] = (float) gk;
			
			// DEBUGGING: {
//			logger.debug( "  [populateGradients] g_k = " + gk );
			// }
		}
		
		assert fequal( 1.f, mag( gi ) );
	}
	return g;
}



